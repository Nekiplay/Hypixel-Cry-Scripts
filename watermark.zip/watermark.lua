register2DRenderer(function(context)
    local obj = {
    	x = 1, y = 4,
    	width = 16, height = 16,
    	path = "config/hypixelcry/scripts/images/logo.png",
    }
    context.renderImage(obj)
    
    local obj2 = {
    	x = 19, y = 3, scale = 1,
    	text = "§6Hypixel Cry §7v1.1.3",
    	red = 0, green = 0, blue = 0
    }
    context.renderText(obj2)
    
    local obj3 = {
    	x = 19, y = 13, scale = 0.75,
    	text = "§7by §bNeki_play§7, §bKreedMan",
    	red = 0, green = 0, blue = 0
    }
    context.renderText(obj3)
end)
