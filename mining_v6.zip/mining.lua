local Vectors = require("vector")
local rotations = require("rotations_v2")

math.randomseed(os.time())

-- Cache frequently used functions
local math_floor = math.floor
local math_abs = math.abs
local math_random = math.random
local pairs = pairs

-- Precompute constants
local TWO_PI = 2 * math.pi
local HALF_PI = math.pi / 2

function readAll(file)
    local f = io.open(file, "r")
    if not f then
        print("Error opening file: " .. (err or "unknown"))
        return nil
    end
    local content = f:read("*a")
    f:close()
    return content
end

local config_raw = readAll("config/hypixelcry/scripts/data/mining.json")
local config_json = json.parse(config_raw)
local positions = config_json.positions

-- Конфигурационные настройки
local CONFIG = {
    ROTATION_SPEED = config_json.config.rotation_speed,
    MINING_RANGE = config_json.config.mining_range,
    PICKBOLUS_DELAY_BEFORE_USE = 15,
    PICKBOLUS_DELAY_HOLD_USE = 5,
    PICKBOLUS_DELAY_AFTER_USE = 6,
    PICKBOLUS_REPEAT_INTERVAL = 950,
    TARGET_CHANGE_DELAY = 1, -- Новая задержка между сменой целей
    DEBUG_MODE = config_json.config.debug_mode
}

-- Состояние скрипта
local STATE = {
    current_position = nil,
    target_block = nil,
    working = true,
    pickbolus_state = 0,
    pickbolus_timer = 0,
    pickbolus_repeat_timer = 0,
    pickbolus_active = false,
    player_pos_cache = {x = 0, y = 0, z = 0},
    player_rot_cache = {yaw = 0, pitch = 0},
    last_position_check = 0,
    was_in_position = false,  -- Добавляем флаг для отслеживания предыдущего состояния
    target_change_cooldown = 0, -- Таймер задержки между сменой целей
    last_target_position = {x = 0, y = 0, z = 0}, -- Последняя позиция цели
    has_rotated_to_target = false, -- Флаг, указывающий, что поворот к цели уже выполнен
    current_target_id = nil, -- Идентификатор текущей цели для отслеживания смены цели
    was_attacking = false -- Флаг для отслеживания состояния атаки
}

-- Вспомогательные функции
local function debugMessage(message)
    if CONFIG.DEBUG_MODE then
        player.addMessage("[DEBUG] " .. message)
    end
end

local function renderLine(context, x, y, z, x2, y2, z2, red, green, blue, line_width)
    context.renderLinesFromPoints({
        points = {
            [0] = { x = x, y = y, z = z },
            [1] = { x = x2, y = y2, z = z2 }
        },
        red = red, green = green, blue = blue, alpha = 140,
        line_width = line_width, through_walls = true
    })
end

local function renderFilledCircle(context, x, y, z, size, segments, red, green, blue, line_width)
    segments = segments or 32
    if segments < 8 then segments = 8 end
    
    local angleStep = TWO_PI / segments
    local centerPoint = {x = x, y = y, z = z}
    
    for i = 0, segments - 1 do
        local angle1 = i * angleStep
        local angle2 = (i + 1) * angleStep
        
        local x1 = x + math.cos(angle1) * size
        local z1 = z + math.sin(angle1) * size
        local x2 = x + math.cos(angle2) * size
        local z2 = z + math.sin(angle2) * size
        
        renderLine(context, centerPoint.x, centerPoint.y, centerPoint.z, x1, y, z1, red, green, blue, line_width)
        renderLine(context, x1, y, z1, x2, y, z2, red, green, blue, line_width)
        renderLine(context, x2, y, z2, centerPoint.x, centerPoint.y, centerPoint.z, red, green, blue, line_width)
    end
end

-- Cache blacklist checks
local blacklist_cache = {}
local function isBlockBlacklisted(blacklist, x, y, z)
    local cache_key = x .. "_" .. y .. "_" .. z
    if blacklist_cache[cache_key] == nil then
        for _, blacklistedBlock in pairs(blacklist) do
            if blacklistedBlock.x == x and blacklistedBlock.y == y and blacklistedBlock.z == z then
                blacklist_cache[cache_key] = true
                break
            end
        end
        blacklist_cache[cache_key] = blacklist_cache[cache_key] or false
    end
    return blacklist_cache[cache_key]
end

local function getCurrentPosition()
    -- Only check position every 10 ticks to reduce overhead
    if STATE.last_position_check > 0 then
        STATE.last_position_check = STATE.last_position_check - 1
        return STATE.current_position
    end
    
    STATE.last_position_check = 10
    local player_pos = player.getPos()
    
    -- Cache player position
    STATE.player_pos_cache.x, STATE.player_pos_cache.y, STATE.player_pos_cache.z = player_pos.x, player_pos.y, player_pos.z
    
    for _, position in pairs(positions) do
        if position.center_x == player_pos.x and position.center_y == player_pos.y and position.center_z == player_pos.z then
            STATE.current_position = position
            return position
        end
    end
    
    STATE.current_position = nil
    return nil
end

-- Cache custom rotations
local custom_rotation_cache = {}
local function getCustomRotationForBlock(x, y, z)
    if not STATE.current_position or not STATE.current_position.custom_rotations then
        return nil, nil
    end
    
    local cache_key = x .. "_" .. y .. "_" .. z
    if custom_rotation_cache[cache_key] then
        return custom_rotation_cache[cache_key].yaw, custom_rotation_cache[cache_key].pitch
    end
    
    for _, custom_rot in pairs(STATE.current_position.custom_rotations) do
        if custom_rot.x == x and custom_rot.y == y and custom_rot.z == z then
            custom_rotation_cache[cache_key] = {yaw = custom_rot.yaw, pitch = custom_rot.pitch}
            return custom_rot.yaw, custom_rot.pitch
        end
    end
    
    custom_rotation_cache[cache_key] = false
    return nil, nil
end

local function findNearestBlock(range)
    if not STATE.current_position then return nil end
    
    local playerX, playerY, playerZ = STATE.player_pos_cache.x, STATE.player_pos_cache.y, STATE.player_pos_cache.z
    local playerRot = player.getRotation()
    local playerYaw, playerPitch = playerRot.yaw or playerRot, playerRot.pitch or 0
    
    -- Cache player rotation
    STATE.player_rot_cache.yaw, STATE.player_rot_cache.pitch = playerYaw, playerPitch
    
    local nearestBlock = nil
    local minAngleDiff = math.huge
    
    local floorX, floorY, floorZ = math_floor(playerX), math_floor(playerY), math_floor(playerZ)

    for dx = -range, range do
        local x = floorX + dx
        for dz = -range, range do
            local z = floorZ + dz
            for dy = -range, range + 2 do
                local y = floorY + dy
                
                if y >= playerY - 1 and not isBlockBlacklisted(STATE.current_position.blacklist, x, y, z) then
                    local blockInfo = world.getBlock(x, y, z)
                    
                    for _, pattern in pairs(STATE.current_position.blocks) do
                        if blockInfo.name:match(pattern) then
                            local customYaw, customPitch = getCustomRotationForBlock(x, y, z)
                            local targetYaw, targetPitch
                            
                            if customYaw and customPitch then
                                targetYaw, targetPitch = customYaw, customPitch
                            else
                                local rot = world.getRotation(x + 0.5, y + 0.5, z + 0.5)
                                targetYaw, targetPitch = rot.yaw, rot.pitch
                            end

                            local yawDiff = math_abs((targetYaw - playerYaw + 180) % 360 - 180)
                            local pitchDiff = math_abs(targetPitch - playerPitch)
                            local totalAngleDiff = yawDiff + pitchDiff
                            
                            if totalAngleDiff < minAngleDiff then
                                minAngleDiff = totalAngleDiff
                                nearestBlock = {
                                    x = x, y = y, z = z,
                                    name = blockInfo.name,
                                    angleDiff = totalAngleDiff,
                                    id = x .. "_" .. y .. "_" .. z -- Уникальный идентификатор блока
                                }
                            end
                            break -- Break pattern loop once found
                        end
                    end
                end
            end
        end
    end
    
    return nearestBlock
end

local function usePickBolus()
    -- Не использовать pickobulus если есть активная цель для майнинга 
    if not STATE.pickbolus_active then
        STATE.pickbolus_repeat_timer = STATE.pickbolus_repeat_timer - 1
        if STATE.pickbolus_repeat_timer <= 0 then
            STATE.pickbolus_active = true
            STATE.pickbolus_state = 0
            STATE.pickbolus_timer = 0
            debugMessage("Pickbolus: Starting new cycle")
        end
        return false
    end
    
    -- State machine for pickbolus
    if STATE.pickbolus_state == 0 then
        rotations.setTargetRotation(STATE.current_position.pickbolus.yaw, STATE.current_position.pickbolus.pitch)
        STATE.pickbolus_state = 1
        STATE.pickbolus_timer = CONFIG.PICKBOLUS_DELAY_BEFORE_USE
        debugMessage("Pickbolus: Setting rotation")
        
    elseif STATE.pickbolus_state == 1 then
        STATE.pickbolus_timer = STATE.pickbolus_timer - 1
        if STATE.pickbolus_timer <= 0 then
            STATE.pickbolus_state = 2
        end
        
    elseif STATE.pickbolus_state == 2 then
        player.input.setPressedUse(true)
        STATE.pickbolus_state = 3
        STATE.pickbolus_timer = CONFIG.PICKBOLUS_DELAY_HOLD_USE
        debugMessage("Pickbolus: Use pressed")
        
    elseif STATE.pickbolus_state == 3 then
        STATE.pickbolus_timer = STATE.pickbolus_timer - 1
        if STATE.pickbolus_timer <= 0 then
            player.input.setPressedUse(false)
            STATE.pickbolus_state = 4
            STATE.pickbolus_timer = CONFIG.PICKBOLUS_DELAY_AFTER_USE
            debugMessage("Pickbolus: Use released")
        end
        
    elseif STATE.pickbolus_state == 4 then
        STATE.pickbolus_timer = STATE.pickbolus_timer - 1
        if STATE.pickbolus_timer <= 0 then
            STATE.pickbolus_active = false
            STATE.pickbolus_repeat_timer = CONFIG.PICKBOLUS_REPEAT_INTERVAL
            STATE.pickbolus_state = -1
            debugMessage("Pickbolus: Cycle completed")
        end
    end
    
    return true
end

local function resetPickBolus()
    STATE.pickbolus_state = 0
    STATE.pickbolus_timer = 0
    STATE.pickbolus_repeat_timer = 0
    STATE.pickbolus_active = false
    player.input.setPressedUse(false)
end

-- Основной тик
registerClientTick(function()
    rotations.update()
    local previous_position = STATE.current_position
    getCurrentPosition()
    
    -- Обновляем таймер задержки между сменой целей
    if STATE.target_change_cooldown > 0 then
        STATE.target_change_cooldown = STATE.target_change_cooldown - 1
    end
    
    -- Проверяем, изменилось ли состояние позиции
    local position_changed = (previous_position ~= nil and STATE.current_position == nil) or
                            (previous_position == nil and STATE.current_position ~= nil)
    
    -- Если игрок только что отошел от точки
    if position_changed and previous_position ~= nil and STATE.current_position == nil then
        if STATE.was_attacking then
            player.input.setPressedAttack(false)
            STATE.was_attacking = false
            debugMessage("Player left position, attack stopped")
        end
        -- Сбрасываем состояние pickobolus при выходе из позиции
        resetPickBolus()
    end
    
    if not STATE.current_position then
        STATE.target_block = nil
        STATE.was_in_position = false  -- Сбрасываем флаг при отсутствии позиции
        STATE.last_target_position = {x = 0, y = 0, z = 0}
        STATE.has_rotated_to_target = false
        STATE.current_target_id = nil
        rotations.stop()
        return
    end
    
    -- Обновляем флаг текущего состояния
    STATE.was_in_position = true
    
    -- Используем pickobulus только если нет активной цели и нет задержки
    local pickbActive = usePickBolus()
    
    if STATE.target_block then
        -- Check if target block still exists
        local blockInfo = world.getBlock(STATE.target_block.x, STATE.target_block.y, STATE.target_block.z)
        if blockInfo.name ~= STATE.target_block.name then
            STATE.target_block = nil
            STATE.has_rotated_to_target = false
            STATE.current_target_id = nil
            STATE.target_change_cooldown = CONFIG.TARGET_CHANGE_DELAY -- Устанавливаем задержку после разрушения блока
            debugMessage("§cBlock destroyed, cooldown started")
            return
        end
    end

    -- Если активен pickobolus, не ищем блоки для майнинга
    if pickbActive then
        STATE.target_block = nil
        STATE.has_rotated_to_target = false
        STATE.current_target_id = nil
        return
    end

    if not STATE.working then
        STATE.has_rotated_to_target = false
        STATE.current_target_id = nil
        return
    end
    
    -- Выполняем поворот только один раз для новой цели
    if not STATE.target_block then
    	STATE.target_block = findNearestBlock(CONFIG.MINING_RANGE)
    	if STATE.target_block then
            player.input.setPressedAttack(true)
            STATE.was_attacking = true  -- Запоминаем, что атака включена
            local customYaw, customPitch = getCustomRotationForBlock(
                STATE.target_block.x, STATE.target_block.y, STATE.target_block.z
            )
            
            if customYaw and customPitch then
                debugMessage("§6Using custom rotation for block: §r" .. STATE.target_block.x .. " " .. STATE.target_block.y .. " " .. STATE.target_block.z)
                rotations.setTargetRotation(
                    customYaw + math_random(-STATE.current_position.randomer.yaw, STATE.current_position.randomer.yaw),
                    customPitch + math_random(-STATE.current_position.randomer.pitch, STATE.current_position.randomer.pitch)
                )
            else
                debugMessage("§2Using default rotation block: §r" .. STATE.target_block.x .. " " .. STATE.target_block.y .. " " .. STATE.target_block.z)
                rotations.rotateToCoordinates(
                    STATE.target_block.x + 0.5 + math_random(-STATE.current_position.randomer.x, STATE.current_position.randomer.x),
                    STATE.target_block.y + 0.5 + math_random(-STATE.current_position.randomer.y, STATE.current_position.randomer.y),
                    STATE.target_block.z + 0.5 + math_random(-STATE.current_position.randomer.x, STATE.current_position.randomer.x)
                )
            end
            
            STATE.has_rotated_to_target = true -- Устанавливаем флаг, что поворот выполнен
        end
    end
    
    -- Raycast check
    local ray = player.raycast(8)
    if ray and ray.type == "entity" then
        debugMessage("Entity detected, stopping")
        player.input.setPressedAttack(false)
        STATE.was_attacking = false
        STATE.target_block = nil
        STATE.has_rotated_to_target = false
        STATE.current_target_id = nil
        STATE.target_change_cooldown = CONFIG.TARGET_CHANGE_DELAY -- Задержка при обнаружении entity
    end
end)

-- Настройка скорости поворота
rotations.setRotationSpeed(CONFIG.ROTATION_SPEED)

-- Рендеринг
registerWorldRenderer(function(context)
    -- Отображаем текущую цель для майнинга
    if STATE.target_block then 
        context.renderFilled({
            x = STATE.target_block.x,
            y = STATE.target_block.y,
            z = STATE.target_block.z,
            red = 255, green = 0, blue = 0, alpha = 140,
            through_walls = false
        })
        
    end
    
    -- Отображаем все позиции из конфига
    for index, position in pairs(positions) do
    	if position ~= STATE.current_position then
            renderFilledCircle(context, position.center_x, position.center_y, position.center_z, 0.25, 16, 255, 85, 85, 3)
            
            context.renderText({
                x = position.center_x,
                y = position.center_y + 0.5,
                z = position.center_z,
                scale = 1,
                red = 255, green = 0, blue = 0,
                text = "§c" .. index,
                through_walls = true
            })
        else
            renderFilledCircle(context, 
            STATE.current_position.center_x, 
            STATE.current_position.center_y, 
            STATE.current_position.center_z, 
            0.45, 16,
            85, 255, 85,
            3
        )

        context.renderText({
            x = STATE.current_position.center_x,
            y = STATE.current_position.center_y + 0.5,
            z = STATE.current_position.center_z,
            scale = 1,
            red = 85, green = 255, blue = 85,
            text = "" .. index,
            through_walls = true
        })
        end
    end
end)

player.addMessage("Mining script loaded!")
return "HWID Accessed"
