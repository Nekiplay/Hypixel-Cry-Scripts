local rotations = require("rotations_v2.lua")
rotations.setRotationSpeed(12)

function readAll(file)
    local f = io.open(file, "r")
    if not f then
        print("Error opening file: " .. (err or "unknown"))
        return nil
    end
    local content = f:read("*a")
    f:close()
    return content
end

local config_raw = readAll("config/hypixelcry/scripts/data/farming.json")
local config = json.parse(config_raw)

local last_pos = nil
local time_between_updates = 0.02

local state = "left"
local stopped = false

function round(exact, quantum)
    local quant,frac = math.modf(exact/quantum)
    return quantum * (quant + (frac > 0.5 and 1 or 0))
end

local grounded = false
local rotated = false

rotations.rotateToYawPitch(config.rotations.yaw, config.rotations.pitch)

registerWorldRenderer(function(context)
    local end_filled = {
        x = config.warp.x, y = config.warp.y + 1, z = config.warp.z,
        red = 255, green = 85, blue = 85, alpha = 140,
        through_walls = false
    }
    context.renderFilled(end_filled)

    local start_filled = {
        x = config.start.x, y = config.start.y + 1, z = config.start.z,
        red = 85, green = 255, blue = 85, alpha = 140,
        through_walls = false
    }
    context.renderFilled(start_filled)
end)

registerClientTick(function()
	rotations.update()

    local pos = player.getPos()
    local position = player.getLocation()

    if position == "GARDEN" then
        if math.floor(pos.x) == config.warp.x and math.floor(pos.z) == config.warp.z then
            player.sendCommand("/warp garden")
            rotations.rotateToYawPitch(config.rotations.yaw, config.rotations.pitch)
        end
        if pos.y == config.ground_height then
            if math.floor(pos.x) == config.start.x and math.floor(pos.z) == config.start.z then
                if not player.isOnGround() then
                    player.input.setPressedSneak(true)
                else
                    player.input.setPressedSneak(false)
                end
            end
            grounded = true
            stopped = false
            local current_time = os.clock()
            if last_pos ~= nil then
                local dx = pos.x - last_pos.x
                local dy = pos.y - last_pos.y
                local dz = pos.z - last_pos.z


                local speed_x = dx / time_between_updates
                local speed_y = dy / time_between_updates
                local speed_z = dz / time_between_updates

                local total_speed = math.sqrt(speed_x*speed_x + speed_y*speed_y + speed_z*speed_z)

                if total_speed <= 0.8 then
                    if state == "left" then
                        state = "right"
                    else
                        state = "left"
                    end
                end
            end

            player.input.setSelectedSlot(0)
            player.input.setPressedSprinting(true)
            player.input.setPressedForward(true)
            player.input.setPressedAttack(true)
            if state == "left" then
                player.input.setPressedLeft(true)
                player.input.setPressedRight(false)
            elseif state == "right" then
                player.input.setPressedRight(true)
                player.input.setPressedLeft(false)

            end
            last_pos = pos
        elseif stopped == false then
            player.input.setPressedRight(false)
            player.input.setPressedLeft(false)
            player.input.setPressedForward(false)
            player.input.setPressedAttack(false)
            stopped = true
        else
            grounded = false
            rotated = false

        end
        if grounded and not rotated then
            rotations.rotateToYawPitch(config.rotations.yaw, config.rotations.pitch)
            rotated = true
        end
    else
        state = "left"
    end
end)    
